/* Signing in - the studio uses the TestMu AI account the browser is already
 * signed in to, and never asks for an access key.
 *
 * The TestMu AI web login leaves an `accessToken` cookie on lambdatest.com.
 * The account service answers /api/user for that token with the username and
 * the API token, which is the pair every HyperExecute and session call takes as
 * Basic auth. That is how the HyperExecute dashboard gets its credentials too.
 *
 * Nothing here is written to storage. The pair lives in this page's memory and
 * is looked up again on the next page load, so signing out of TestMu AI signs
 * the studio out as well, and there is no copy of the key on disk to leak.
 *
 * The account button in the page bar names the account and opens TestMu AI's
 * logout, which lands on the login page: that is how you sign out, and how you
 * come back as a different account. The page follows along by itself, because
 * it is watching the cookie either way.
 */

const AUTH_ACCOUNTS = "https://accounts.lambdatest.com";
const AUTH_COOKIE = "accessToken";
/* /logout clears the session and redirects to /login, so one link covers both
   signing out and coming back as someone else. */
const AUTH_LOGOUT = AUTH_ACCOUNTS + "/logout";

let AUTH_ACCOUNT = null;        // {user, key} once signed in
let AUTH_TOKEN = null;          // the cookie value AUTH_ACCOUNT was looked up with

async function authToken() {
  const c = await chrome.cookies.get({ url: AUTH_ACCOUNTS + "/", name: AUTH_COOKIE });
  if (!c || !c.value) return null;
  try { return decodeURIComponent(c.value); } catch (e) { return c.value; }
}

/* null means signed out (no token, or a token the service no longer accepts);
   anything else going wrong is thrown, so a network failure is not mistaken
   for being signed out. */
async function authLookup(token) {
  const r = await fetch(AUTH_ACCOUNTS + "/api/user", {
    headers: { authorization: "Bearer " + token, accept: "application/json" },
    credentials: "omit",
  });
  if (r.status === 401 || r.status === 403) return null;
  if (!r.ok) throw new Error(`the TestMu AI account service returned HTTP ${r.status}`);
  const j = await r.json();
  if (!j || !j.username || !j.apiToken) {
    throw new Error("the TestMu AI account service answered without a username and API token");
  }
  return { user: String(j.username), key: String(j.apiToken) };
}

/* The pair for an API call. Throws when signed out, so callers need no check
   of their own; the gate is already covering the page in that case. */
function authCreds() {
  if (!AUTH_ACCOUNT) throw new Error("sign in to TestMu AI first");
  return { user: AUTH_ACCOUNT.user, key: AUTH_ACCOUNT.key };
}

/* ---- the gate ----------------------------------------------------------- */

function authGateEl() {
  let g = document.getElementById("authGate");
  if (g) return g;
  g = document.createElement("div");
  g.id = "authGate";
  g.className = "authgate";
  g.setAttribute("role", "dialog");
  g.setAttribute("aria-modal", "true");
  g.setAttribute("aria-labelledby", "authGateTitle");
  g.innerHTML = `
    <div class="authcard">
      <h2 id="authGateTitle">Sign in to use JMeter Studio</h2>
      <p id="authGateText">JMeter Studio uses your TestMu AI account. Log in the
        way you always do - Google, GitHub, SSO or a password - and this page
        unlocks by itself. There is no access key to copy.</p>
      <button type="button" class="go" id="authSignIn">Log in to TestMu AI</button>
      <button type="button" class="alt" id="authSwitch" hidden>Log out of TestMu AI</button>
      <button type="button" class="alt" id="authCancel" hidden>Cancel</button>
      <p class="authnote" id="authGateNote"></p>
    </div>`;
  document.body.appendChild(g);
  g.querySelector("#authSignIn").onclick = () =>
    chrome.tabs.create({ url: AUTH_ACCOUNTS + "/login" });
  g.querySelector("#authSwitch").onclick = () =>
    chrome.tabs.create({ url: AUTH_LOGOUT });
  return g;
}

function authRender(state, detail) {
  const g = authGateEl();
  const chip = document.getElementById("account");
  // "manage" is the signed-in page asking what to do about its account, so the
  // card is over the page without the page being locked out
  const locked = state !== "in" && state !== "manage";
  g.hidden = state === "in";
  document.body.classList.toggle("signed-out", locked);

  const note = g.querySelector("#authGateNote");
  if (state === "checking") note.textContent = "checking your TestMu AI login\u2026";
  else if (state === "expired") note.textContent = "Your TestMu AI session has ended. Log in again to continue.";
  else if (state === "error") note.textContent = "Could not check your login: " + detail;
  else if (state === "manage") note.textContent = "";
  else note.textContent = "Waiting for you to log in - this page unlocks by itself.";

  const title = g.querySelector("#authGateTitle");
  const text = g.querySelector("#authGateText");
  if (state === "manage") {
    title.textContent = "Signed in as " + AUTH_ACCOUNT.user;
    text.textContent = "Logging out opens the TestMu AI login page, so this is "
      + "also how you come back as a different account. This page locks until "
      + "you do, and unlocks again by itself.";
  } else {
    title.textContent = "Sign in to use JMeter Studio";
    text.textContent = "JMeter Studio uses your TestMu AI account. Log in the "
      + "way you always do - Google, GitHub, SSO or a password - and this page "
      + "unlocks by itself. There is no access key to copy.";
  }

  g.querySelector("#authSignIn").hidden = state === "checking" || state === "manage";
  g.querySelector("#authSwitch").hidden = state !== "manage";
  g.querySelector("#authCancel").hidden = state !== "manage";

  if (chip) {
    chip.hidden = locked;
    if (AUTH_ACCOUNT) {
      chip.textContent = AUTH_ACCOUNT.user;
      chip.title = "Signed in to TestMu AI as " + AUTH_ACCOUNT.user
        + " - click to log out or switch account";
    }
  }
}

/* Resolves once someone is signed in, and keeps the page in step with the
   browser's sign-in afterwards. A different account signing in reloads the
   page, so nothing chosen for the old account (a project, a session) carries
   over to the new one. */
function authReady() {
  return new Promise((resolve) => {
    let resolved = false;
    let unlockedFor = null;       // the account this page was first unlocked for
    let busy = null;

    async function check() {
      const token = await authToken();
      if (!token) {
        AUTH_ACCOUNT = AUTH_TOKEN = null;
        return authRender("out");
      }
      if (token === AUTH_TOKEN && AUTH_ACCOUNT) return;
      let account;
      try {
        account = await authLookup(token);
      } catch (e) {
        AUTH_ACCOUNT = AUTH_TOKEN = null;
        return authRender("error", e.message || String(e));
      }
      if (!account) {
        AUTH_ACCOUNT = AUTH_TOKEN = null;
        return authRender("expired");
      }
      if (unlockedFor && unlockedFor !== account.user) {
        location.reload();
        return;
      }
      AUTH_ACCOUNT = account;
      AUTH_TOKEN = token;
      authRender("in");
      if (!resolved) { resolved = true; unlockedFor = account.user; resolve(account); }
    }

    const run = () => { busy = (busy || Promise.resolve()).then(check).catch(() => {}); };

    const g = authGateEl();
    g.querySelector("#authCancel").onclick = () => authRender("in");
    const chip = document.getElementById("account");
    if (chip) chip.onclick = () => { if (AUTH_ACCOUNT) authRender("manage"); };

    chrome.cookies.onChanged.addListener(({ cookie }) => {
      if (cookie.name === AUTH_COOKIE && /(^|\.)lambdatest\.com$/.test(cookie.domain)) run();
    });
    // a tab left open overnight is re-checked when it is looked at again
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") run();
    });

    authRender("checking");
    run();
  });
}

window.AUTH = { ready: authReady, creds: authCreds };
